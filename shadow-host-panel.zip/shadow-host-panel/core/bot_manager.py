import asyncio
import os
import signal
import subprocess
import time
from pathlib import Path
from sqlalchemy import select
from sqlalchemy.orm import Session

class BotManager:
    def __init__(self, root: str):
        self.root = Path(root)
        self.processes = {}

    def discover(self, db: Session):
        from main import Bot
        known = {b.name for b in db.scalars(select(Bot)).all()}
        for path in self.root.iterdir() if self.root.exists() else []:
            if path.is_dir() and path.name not in known:
                bot = Bot(name=path.name, path=str(path), startup_cmd="python main.py", status="stopped", auto_restart=False)
                db.add(bot)
        db.commit()

    def start(self, db: Session, bot_id: int):
        from main import Bot
        bot = db.get(Bot, bot_id)
        if not bot:
            return None
        if bot_id in self.processes and self.processes[bot_id].poll() is None:
            return bot
        Path(bot.path).mkdir(parents=True, exist_ok=True)
        log = Path(bot.path) / "bot.log"
        handle = open(log, "a", encoding="utf-8")
        process = subprocess.Popen(bot.startup_cmd, cwd=bot.path, shell=True, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
        self.processes[bot_id] = process
        bot.pid, bot.status, bot.last_started = process.pid, "running", time.time()
        db.commit()
        return bot

    def stop(self, db: Session, bot_id: int, force=False):
        from main import Bot
        bot = db.get(Bot, bot_id)
        process = self.processes.get(bot_id)
        if process and process.poll() is None:
            try:
                os.killpg(os.getpgid(process.pid), signal.SIGKILL if force else signal.SIGTERM)
            except ProcessLookupError:
                pass
        if bot:
            bot.status, bot.pid = "stopped", None
            db.commit()
        return bot

    def restart(self, db: Session, bot_id: int):
        self.stop(db, bot_id)
        return self.start(db, bot_id)

    def sync(self, db: Session):
        from main import Bot
        for bot in db.scalars(select(Bot)).all():
            proc = self.processes.get(bot.id)
            alive = proc is not None and proc.poll() is None
            if alive:
                bot.status, bot.pid = "running", proc.pid
            elif bot.status == "running":
                bot.status, bot.pid = "crashed", None
                if bot.auto_restart:
                    self.start(db, bot.id)
        db.commit()

    async def watchdog(self, factory):
        while True:
            try:
                with factory() as db:
                    self.sync(db)
            except Exception:
                pass
            await asyncio.sleep(5)
