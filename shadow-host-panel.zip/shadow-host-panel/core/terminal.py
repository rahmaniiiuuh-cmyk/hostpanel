import asyncio
import os
import pty
import select
import subprocess
from fastapi import WebSocket

async def terminal_socket(websocket: WebSocket):
    await websocket.accept()
    pid, fd = pty.fork()
    if pid == 0:
        os.execvp("bash", ["bash"])
    try:
        while True:
            data = await websocket.receive_text()
            if data == "__resize__":
                continue
            os.write(fd, data.encode())
            await asyncio.sleep(0.03)
            output = b""
            while select.select([fd], [], [], 0)[0]:
                output += os.read(fd, 4096)
            if output:
                await websocket.send_text(output.decode(errors="replace"))
    except Exception:
        try: os.kill(pid, 9)
        except OSError: pass
