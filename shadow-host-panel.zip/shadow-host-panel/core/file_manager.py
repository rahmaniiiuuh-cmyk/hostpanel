import shutil
import zipfile
from pathlib import Path

class FileManager:
    def __init__(self, root: str):
        self.root = Path(root).resolve()

    def safe(self, bot: str, rel: str = "") -> Path:
        path = (self.root / bot / rel).resolve()
        if path != (self.root / bot).resolve() and (self.root / bot).resolve() not in path.parents:
            raise ValueError("Invalid path")
        return path

    def tree(self, bot: str):
        base = self.safe(bot)
        base.mkdir(parents=True, exist_ok=True)
        return [{"name": str(p.relative_to(base)), "type": "dir" if p.is_dir() else "file", "size": p.stat().st_size if p.is_file() else 0} for p in sorted(base.rglob("*"))]

    def write(self, bot: str, rel: str, content: str):
        path = self.safe(bot, rel); path.parent.mkdir(parents=True, exist_ok=True); path.write_text(content, encoding="utf-8"); return path

    def delete(self, bot: str, rel: str):
        path = self.safe(bot, rel)
        if path.is_dir(): shutil.rmtree(path)
        elif path.exists(): path.unlink()

    def zip(self, bot: str, rel: str = ""):
        source = self.safe(bot, rel); target = source.with_suffix(".zip")
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
            for item in source.rglob("*"):
                if item.is_file(): archive.write(item, item.relative_to(source))
        return target
