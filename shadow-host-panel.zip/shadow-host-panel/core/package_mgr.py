import json
import subprocess
import urllib.request

def installed():
    result = subprocess.run(["python", "-m", "pip", "list", "--format=json"], capture_output=True, text=True)
    try: return json.loads(result.stdout)
    except json.JSONDecodeError: return []

def run(action: str, package: str):
    if not package.replace("-", "").replace("_", "").isalnum(): raise ValueError("Invalid package")
    command = ["python", "-m", "pip", action, package]
    return subprocess.run(command, capture_output=True, text=True, timeout=180).stdout[-4000:]

def search(package: str):
    with urllib.request.urlopen("https://pypi.org/pypi/" + package + "/json", timeout=8) as response:
        data = json.load(response)
    return {"name": data["info"]["name"], "version": data["info"]["version"], "summary": data["info"]["summary"]}
