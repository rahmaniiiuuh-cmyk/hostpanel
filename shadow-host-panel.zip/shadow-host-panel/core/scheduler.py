import asyncio

async def scheduler_loop(backup_manager, db_factory, db_file):
    while True:
        await asyncio.sleep(86400)
        try:
            backup_manager.create(db_file)
        except Exception:
            pass
