import shutil
import time
import zipfile
from pathlib import Path

class BackupManager:
    def __init__(self, data: str):
        self.data = Path(data); self.dir = self.data / "backups"; self.dir.mkdir(parents=True, exist_ok=True)

    def create(self, db_file: str):
        name = "shadow-backup-" + time.strftime("%Y%m%d-%H%M%S") + ".zip"
        target = self.dir / name
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
            bots = self.data / "bots"
            if bots.exists():
                for p in bots.rglob("*"):
                    if p.is_file(): archive.write(p, p.relative_to(self.data))
            if Path(db_file).exists(): archive.write(db_file, "db.sqlite")
        return target

    def restore(self, filename: str, db_file: str):
        with zipfile.ZipFile(self.dir / filename) as archive:
            archive.extractall(self.data)
        return True
