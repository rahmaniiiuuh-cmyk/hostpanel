import time
import psutil

_started = time.time()
_last_net = psutil.net_io_counters()
_last_time = time.time()

def metrics():
    global _last_net, _last_time
    now = time.time()
    net = psutil.net_io_counters()
    elapsed = max(now - _last_time, 0.1)
    result = {
        "cpu": round(psutil.cpu_percent(interval=None), 1),
        "ram": round(psutil.virtual_memory().percent, 1),
        "disk": round(psutil.disk_usage("/").percent, 1),
        "network_in": round((net.bytes_recv - _last_net.bytes_recv) / elapsed / 1024, 1),
        "network_out": round((net.bytes_sent - _last_net.bytes_sent) / elapsed / 1024, 1),
        "uptime": int(now - _started),
    }
    _last_net, _last_time = net, now
    return result

def process_snapshot():
    rows = []
    for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info", "cmdline"]):
        try:
            info = proc.info
            cmd = " ".join(info.get("cmdline") or [])
            if "python" in (info.get("name") or "").lower() or "python" in cmd.lower():
                rows.append({"pid": info["pid"], "name": info.get("name") or "python", "cpu": round(info.get("cpu_percent") or 0, 1), "ram": round((info.get("memory_info").rss if info.get("memory_info") else 0) / 1024 / 1024, 1), "cmd": cmd[:160]})
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return rows
