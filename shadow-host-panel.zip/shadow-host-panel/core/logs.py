from datetime import datetime
from pathlib import Path

class LogManager:
    def __init__(self, root: str): self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True)
    def write(self, name: str, message: str, level="INFO"):
        with open(self.root / name, "a", encoding="utf-8") as f: f.write(f"{datetime.now().isoformat()} [{level}] {message}\n")
    def read(self, name: str, limit=200):
        path = self.root / name
        return path.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:] if path.exists() else []
