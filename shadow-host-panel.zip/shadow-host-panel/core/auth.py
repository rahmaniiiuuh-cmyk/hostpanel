import os
from datetime import datetime, timedelta, timezone
from typing import Optional
from jose import jwt, JWTError
from passlib.context import CryptContext
from fastapi import Request
from sqlalchemy import select
from sqlalchemy.orm import Session

SECRET_KEY = os.getenv("SECRET_KEY", "change-this-in-production")
ALGORITHM = "HS256"
SESSION_MINUTES = 30
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_value(value: str) -> str:
    safe_value = value.encode("utf-8")[:72].decode("utf-8", errors="ignore")
    return pwd_context.hash(safe_value)

def verify_value(value: str, hashed: str) -> bool:
    safe_value = value.encode("utf-8")[:72].decode("utf-8", errors="ignore")
    return pwd_context.verify(safe_value, hashed)

def create_token(user_id: int) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub": str(user_id), "iat": now, "exp": now + timedelta(minutes=SESSION_MINUTES)}, SECRET_KEY, algorithm=ALGORITHM)

def decode_token(token: str) -> Optional[int]:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return int(payload["sub"])
    except (JWTError, KeyError, TypeError, ValueError):
        return None

def current_user(request: Request, db: Session):
    token = request.cookies.get("shadow_session")
    user_id = decode_token(token) if token else None
    if not user_id:
        return None
    from main import User
    return db.get(User, user_id)

def authenticate(db: Session, username: str, password: str, pin: str = ""):
    from main import User
    user = db.scalar(select(User).where(User.username == username))
    if not user or not verify_value(password, user.password_hash):
        return None
    if user.pin_hash and (not pin or not verify_value(pin, user.pin_hash)):
        return None
    return user
